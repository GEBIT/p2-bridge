<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='profile' timestamp='1765455467884'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='C:\dev\projects\TestCases\gebit-oomph-master2\git\p2-bridge\p2-runtime\src\main\resources\eclipse'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=de_DE'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='C:\dev\projects\TestCases\gebit-oomph-master2\git\p2-bridge\p2-runtime\src\main\resources\eclipse'/>
  </properties>
  <units size='65'>
    <unit id='a.jre.javase' version='9.0.0' singleton='false'>
      <provides size='248'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' version='9.0.0'/>
        <provided namespace='java.package' name='java.applet' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.color' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.datatransfer' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.desktop' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.event' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.font' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.geom' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.im' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.im.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.image' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.image.renderable' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.print' version='0.0.0'/>
        <provided namespace='java.package' name='java.beans' version='0.0.0'/>
        <provided namespace='java.package' name='java.beans.beancontext' version='0.0.0'/>
        <provided namespace='java.package' name='java.io' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.annotation' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.instrument' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.invoke' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.management' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.module' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.ref' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.reflect' version='0.0.0'/>
        <provided namespace='java.package' name='java.math' version='0.0.0'/>
        <provided namespace='java.package' name='java.net' version='0.0.0'/>
        <provided namespace='java.package' name='java.net.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.channels' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.channels.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.charset' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.charset.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.file' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.file.attribute' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.file.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.activation' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.dgc' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.registry' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.server' version='0.0.0'/>
        <provided namespace='java.package' name='java.security' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.acl' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.cert' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.interfaces' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.spec' version='0.0.0'/>
        <provided namespace='java.package' name='java.sql' version='0.0.0'/>
        <provided namespace='java.package' name='java.text' version='0.0.0'/>
        <provided namespace='java.package' name='java.text.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.time' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.chrono' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.format' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.temporal' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.zone' version='0.0.0'/>
        <provided namespace='java.package' name='java.util' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.concurrent' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.concurrent.atomic' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.concurrent.locks' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.function' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.jar' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.logging' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.prefs' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.regex' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.stream' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.zip' version='0.0.0'/>
        <provided namespace='java.package' name='javax.accessibility' version='0.0.0'/>
        <provided namespace='java.package' name='javax.activation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.activity' version='0.0.0'/>
        <provided namespace='java.package' name='javax.annotation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.annotation.processing' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.interfaces' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.spec' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.metadata' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.bmp' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.jpeg' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.jws' version='0.0.0'/>
        <provided namespace='java.package' name='javax.jws.soap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.element' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.type' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.loading' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.modelmbean' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.monitor' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.openmbean' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.relation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.timer' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.directory' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.ldap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute.standard' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.rmi.CORBA' version='0.0.0'/>
        <provided namespace='java.package' name='javax.rmi.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.script' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.callback' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.kerberos' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.login' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.x500' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.cert' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.sasl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.serial' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.border' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.colorchooser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.filechooser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.basic' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.metal' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.multi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.nimbus' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.synth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.table' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html.parser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.rtf' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.tree' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.undo' version='0.0.0'/>
        <provided namespace='java.package' name='javax.tools' version='0.0.0'/>
        <provided namespace='java.package' name='javax.transaction' version='0.0.0'/>
        <provided namespace='java.package' name='javax.transaction.xa' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.annotation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.annotation.adapters' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.attachment' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.keyinfo' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.spec' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.datatype' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.namespace' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.parsers' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.soap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.events' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.sax' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stax' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.validation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.handler' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.handler.soap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.http' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.soap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.spi.http' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.wsaddressing' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.ietf.jgss' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA_2_3' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA_2_3.portable' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA.DynAnyPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA.ORBPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA.portable' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA.TypeCodePackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CosNaming' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CosNaming.NamingContextExtPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CosNaming.NamingContextPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.Dynamic' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.DynamicAny' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.DynamicAny.DynAnyFactoryPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.DynamicAny.DynAnyPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.IOP' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.IOP.CodecFactoryPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.IOP.CodecPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.Messaging' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableInterceptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableInterceptor.ORBInitInfoPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.CurrentPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.POAManagerPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.POAPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.portable' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.ServantLocatorPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.SendingContext' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.stub.java.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.bootstrap' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.css' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.html' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ls' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ranges' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.stylesheets' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.traversal' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.views' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.ext' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.helpers' version='0.0.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.0.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.1.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.2.0'/>
        <provided namespace='osgi.ee' name='JRE' version='1.0.0'/>
        <provided namespace='osgi.ee' name='JRE' version='1.1.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.1.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.2.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.3.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.4.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.5.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.6.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.7.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='9.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact1' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact1' version='9.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact2' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact2' version='9.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact3' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact3' version='9.0.0'/>
      </provides>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='com.jcraft.jsch' version='0.1.55.v20190404-1902' singleton='false' generation='2'>
      <update id='com.jcraft.jsch' range='[0.0.0,0.1.55.v20190404-1902)' severity='0'/>
      <properties size='4'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='JSch'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.jcraft.jsch' version='0.1.55.v20190404-1902'/>
        <provided namespace='osgi.bundle' name='com.jcraft.jsch' version='0.1.55.v20190404-1902'/>
        <provided namespace='java.package' name='com.jcraft.jsch' version='0.1.55'/>
        <provided namespace='java.package' name='com.jcraft.jsch.jce' version='0.1.55'/>
        <provided namespace='java.package' name='com.jcraft.jsch.jcraft' version='0.1.55'/>
        <provided namespace='java.package' name='com.jcraft.jsch.jgss' version='0.1.55'/>
        <provided namespace='osgi.identity' name='com.jcraft.jsch' version='0.1.55.v20190404-1902'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='java.package' name='com.jcraft.jzlib' range='1.0.7' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.jcraft.jsch' range='[0.1.0,1.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto.interfaces' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.ietf.jgss' range='0.0.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            com.jcraft.jsch
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.jcraft.jsch' version='0.1.55.v20190404-1902'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.jcraft.jsch&#xA;Bundle-Version: 0.1.55.v20190404-1902
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='javax.servlet' version='3.1.0.v201410161800' singleton='false' generation='2'>
      <update id='javax.servlet' range='[0.0.0,3.1.0.v201410161800)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.bundleName' value='Servlet API Bundle'/>
        <property name='df_LT.bundleDescription' value='Java(TM) Servlet 3.1 API Design Specification'/>
        <property name='df_LT.bundleProvider' value='Eclipse Orbit'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.description' value='%bundleDescription'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleProvider'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://glassfish.dev.java.net'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='javax.servlet' version='3.1.0.v201410161800'/>
        <provided namespace='osgi.bundle' name='javax.servlet' version='3.1.0.v201410161800'/>
        <provided namespace='java.package' name='javax.servlet' version='3.1.0'/>
        <provided namespace='java.package' name='javax.servlet.annotation' version='3.1.0'/>
        <provided namespace='java.package' name='javax.servlet.descriptor' version='3.1.0'/>
        <provided namespace='java.package' name='javax.servlet.http' version='3.1.0'/>
        <provided namespace='osgi.identity' name='javax.servlet' version='3.1.0.v201410161800'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.contract' name='JavaServlet' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='java.package' name='javax.servlet' range='3.1.0'/>
        <required namespace='java.package' name='javax.servlet.annotation' range='3.1.0'/>
        <required namespace='java.package' name='javax.servlet.descriptor' range='3.1.0'/>
        <required namespace='java.package' name='javax.servlet.http' range='3.1.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'>
          <description>
            javax.servlet
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='javax.servlet' version='3.1.0.v201410161800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: javax.servlet&#xA;Bundle-Version: 3.1.0.v201410161800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='javax.xml' version='1.3.4.v201005080400' singleton='false' generation='2'>
      <update id='javax.xml' range='[0.0.0,1.3.4.v201005080400)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.Bundle-Vendor.0' value='Eclipse Orbit'/>
        <property name='df_LT.Bundle-Name.0' value='JAXP XML'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name.0'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor.0'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='30'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='javax.xml' version='1.3.4.v201005080400'/>
        <provided namespace='osgi.bundle' name='javax.xml' version='1.3.4.v201005080400'/>
        <provided namespace='java.package' name='javax.xml' version='1.3.0'/>
        <provided namespace='java.package' name='javax.xml.datatype' version='1.3.0'/>
        <provided namespace='java.package' name='javax.xml.namespace' version='1.3.0'/>
        <provided namespace='java.package' name='javax.xml.parsers' version='1.3.0'/>
        <provided namespace='java.package' name='javax.xml.transform' version='1.3.0'/>
        <provided namespace='java.package' name='javax.xml.transform.dom' version='1.3.0'/>
        <provided namespace='java.package' name='javax.xml.transform.sax' version='1.3.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stream' version='1.3.0'/>
        <provided namespace='java.package' name='javax.xml.validation' version='1.3.0'/>
        <provided namespace='java.package' name='javax.xml.xpath' version='1.3.0'/>
        <provided namespace='java.package' name='org.apache.xmlcommons' version='1.3.4'/>
        <provided namespace='java.package' name='org.w3c.dom' version='3.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.bootstrap' version='3.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.css' version='2.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.events' version='2.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.html' version='2.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ls' version='2.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ranges' version='2.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.stylesheets' version='2.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.traversal' version='2.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.views' version='2.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.xpath' version='3.0.0'/>
        <provided namespace='java.package' name='org.xml.sax' version='2.0.2'/>
        <provided namespace='java.package' name='org.xml.sax.ext' version='2.0.2'/>
        <provided namespace='java.package' name='org.xml.sax.helpers' version='2.0.2'/>
        <provided namespace='osgi.identity' name='javax.xml' version='1.3.4.v201005080400'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.2))'>
          <description>
            javax.xml
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='javax.xml' version='1.3.4.v201005080400'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: javax.xml&#xA;Bundle-Version: 1.3.4.v201005080400
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.commons.codec' version='1.13.0.v20200108-0001' singleton='false' generation='2'>
      <update id='org.apache.commons.codec' range='[0.0.0,1.13.0.v20200108-0001)' severity='0'/>
      <properties size='6'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Apache Commons Codec'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.description' value='The Apache Commons Codec package contains simple encoder and decoders for     various formats such as Base64 and Hexadecimal.  In addition to these     widely used encoders and decoders, the codec package also maintains a     collection of phonetic encoding utilities.'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://commons.apache.org/proper/commons-codec/'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.codec' version='1.13.0.v20200108-0001'/>
        <provided namespace='osgi.bundle' name='org.apache.commons.codec' version='1.13.0.v20200108-0001'/>
        <provided namespace='java.package' name='org.apache.commons.codec' version='1.13.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.binary' version='1.13.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.cli' version='1.13.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.digest' version='1.13.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.language' version='1.13.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.language.bm' version='1.13.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.net' version='1.13.0'/>
        <provided namespace='osgi.identity' name='org.apache.commons.codec' version='1.13.0.v20200108-0001'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='java.package' name='javax.crypto' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.codec' range='[1.13.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.codec.binary' range='[1.13.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.codec.digest' range='[1.13.0,2.0.0)' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'>
          <description>
            org.apache.commons.codec
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.commons.codec' version='1.13.0.v20200108-0001'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.commons.codec&#xA;Bundle-Version: 1.13.0.v20200108-0001
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.commons.httpclient' version='3.1.0.v201012070820' singleton='false' generation='2'>
      <update id='org.apache.commons.httpclient' range='[0.0.0,3.1.0.v201012070820)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleName' value='Apache Commons Httpclient'/>
        <property name='df_LT.bundleProvider' value='Eclipse Orbit'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleProvider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.httpclient' version='3.1.0.v201012070820'/>
        <provided namespace='osgi.bundle' name='org.apache.commons.httpclient' version='3.1.0.v201012070820'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.auth' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.cookie' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.methods' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.methods.multipart' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.params' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.protocol' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.util' version='3.1.0'/>
        <provided namespace='osgi.identity' name='org.apache.commons.httpclient' version='3.1.0.v201012070820'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='java.package' name='javax.crypto' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.net' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.net.ssl' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.codec' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.commons.codec.binary' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.commons.codec.net' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.commons.logging' range='[1.0.4,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(|(&amp;(osgi.ee=CDC/Foundation)(version=1.0))(&amp;(osgi.ee=JavaSE)(version=1.2)))'>
          <description>
            org.apache.commons.httpclient
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.commons.httpclient' version='3.1.0.v201012070820'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.commons.httpclient&#xA;Bundle-Version: 3.1.0.v201012070820
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.commons.logging' version='1.2.0.v20180409-1502' singleton='false' generation='2'>
      <update id='org.apache.commons.logging' range='[0.0.0,1.2.0.v20180409-1502)' severity='0'/>
      <properties size='6'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Apache Commons Logging'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.description' value='Apache Commons Logging is a thin adapter allowing configurable bridging to other,    well known logging systems.'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://commons.apache.org/proper/commons-logging/'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.logging' version='1.2.0.v20180409-1502'/>
        <provided namespace='osgi.bundle' name='org.apache.commons.logging' version='1.2.0.v20180409-1502'/>
        <provided namespace='java.package' name='org.apache.commons.logging.impl' version='1.2.0'/>
        <provided namespace='java.package' name='org.apache.commons.logging' version='1.2.0'/>
        <provided namespace='osgi.identity' name='org.apache.commons.logging' version='1.2.0.v20180409-1502'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='java.package' name='javax.servlet' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.avalon.framework.logger' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.logging' range='[1.2.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.logging.impl' range='[1.2.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.log' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.log4j' range='0.0.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.2))'>
          <description>
            org.apache.commons.logging
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.commons.logging' version='1.2.0.v20180409-1502'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.commons.logging&#xA;Bundle-Version: 1.2.0.v20180409-1502
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.felix.scr' version='2.1.16.v20200110-1820' singleton='false' generation='2'>
      <update id='org.apache.felix.scr' range='[0.0.0,2.1.16.v20200110-1820)' severity='0'/>
      <properties size='6'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Apache Felix Declarative Services'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.description' value='Implementation of the Declarative Services specification 1.4'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://felix.apache.org/site/apache-felix-service-component-runtime.html'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.scr' version='2.1.16.v20200110-1820'/>
        <provided namespace='osgi.bundle' name='org.apache.felix.scr' version='2.1.16.v20200110-1820'/>
        <provided namespace='java.package' name='org.apache.felix.scr.component' version='1.1.0'/>
        <provided namespace='java.package' name='org.apache.felix.scr.info' version='1.0.0'/>
        <provided namespace='osgi.identity' name='org.apache.felix.scr' version='2.1.16.v20200110-1820'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.extender' name='osgi.component' version='1.4.0'/>
        <provided namespace='osgi.service' name='org.apache.felix.scr_2.1.16.v20200110-1820-2' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.component.runtime.ServiceComponentRuntime' type='List'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='19'>
        <required namespace='java.package' name='org.apache.felix.service.command' range='[1.0.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.dto' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.dto' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.cm' range='[1.6.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.component' range='[1.4.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime' range='[1.4.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime.dto' range='[1.4.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.3.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.metatype' range='[1.2.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.promise' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.felix.scr.component' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.apache.felix.scr.info' range='[1.0.0,1.1.0)'/>
        <required namespace='java.package' name='org.apache.felix.shell' range='[1.0.0,2.0.0)' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'>
          <description>
            org.apache.felix.scr
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.felix.scr' version='2.1.16.v20200110-1820'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.felix.scr&#xA;Bundle-Version: 2.1.16.v20200110-1820
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.httpcomponents.httpclient' version='4.5.10.v20200114-1512' singleton='false' generation='2'>
      <update id='org.apache.httpcomponents.httpclient' range='[0.0.0,4.5.10.v20200114-1512)' severity='0'/>
      <properties size='4'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Apache HttpClient'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
      </properties>
      <provides size='36'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.httpcomponents.httpclient' version='4.5.10.v20200114-1512'/>
        <provided namespace='osgi.bundle' name='org.apache.httpcomponents.httpclient' version='4.5.10.v20200114-1512'/>
        <provided namespace='java.package' name='org.apache.http.auth' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.auth.params' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.client' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.client.cache' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.client.config' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.client.entity' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.client.fluent' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.client.methods' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.client.params' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.client.protocol' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.client.utils' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.conn' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.conn.params' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.conn.routing' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.conn.scheme' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.conn.socket' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.conn.ssl' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.conn.util' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.cookie' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.cookie.params' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.entity.mime' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.entity.mime.content' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.impl.auth' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.impl.client' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.impl.client.cache' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.impl.client.cache.ehcache' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.impl.client.cache.memcached' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.impl.conn' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.impl.conn.tsccm' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.impl.cookie' version='4.5.10'/>
        <provided namespace='java.package' name='org.apache.http.impl.execchain' version='4.5.10'/>
        <provided namespace='osgi.identity' name='org.apache.httpcomponents.httpclient' version='4.5.10.v20200114-1512'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='59'>
        <required namespace='java.package' name='org.apache.http.auth' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.auth.params' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.client' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.client.cache' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.client.config' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.client.entity' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.client.methods' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.client.params' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.client.protocol' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.client.utils' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.conn' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.conn.params' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.conn.routing' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.conn.scheme' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.conn.socket' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.conn.ssl' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.conn.util' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.cookie' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.cookie.params' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.entity.mime.content' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.auth' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.client' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.client.cache' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.conn' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.cookie' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.execchain' range='[4.5.10,4.5.11)'/>
        <required namespace='java.package' name='org.apache.http' range='[4.4.12,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.concurrent' range='[4.4.12,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.config' range='[4.4.12,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.entity' range='[4.4.12,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.impl' range='[4.4.12,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.entity' range='[4.4.12,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.io' range='[4.4.12,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.io' range='[4.4.12,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.message' range='[4.4.12,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.params' range='[4.4.12,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.pool' range='[4.4.12,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.protocol' range='[4.4.12,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.ssl' range='[4.4.12,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.util' range='[4.4.12,4.5.0)'/>
        <required namespace='java.package' name='org.apache.commons.codec.binary' range='[1.13.0,1.14.0)'/>
        <required namespace='java.package' name='org.apache.commons.logging' range='[1.2.0,1.3.0)'/>
        <required namespace='java.package' name='net.sf.ehcache' range='[2.6.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='net.spy.memcached' range='[2.12.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.naming' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.naming.directory' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.naming.ldap' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.net' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.net.ssl' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.security.auth.x500' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.ietf.jgss' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.client.fluent' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.entity.mime' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.client.cache.ehcache' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.client.cache.memcached' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.conn.tsccm' range='[4.5.0,5.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.6))'>
          <description>
            org.apache.httpcomponents.httpclient
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.httpcomponents.httpclient' version='4.5.10.v20200114-1512'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.httpcomponents.httpclient&#xA;Bundle-Version: 4.5.10.v20200114-1512
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.httpcomponents.httpcore' version='4.4.12.v20200108-1212' singleton='false' generation='2'>
      <update id='org.apache.httpcomponents.httpcore' range='[0.0.0,4.4.12.v20200108-1212)' severity='0'/>
      <properties size='4'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Apache HttpCore'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
      </properties>
      <provides size='22'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.httpcomponents.httpcore' version='4.4.12.v20200108-1212'/>
        <provided namespace='osgi.bundle' name='org.apache.httpcomponents.httpcore' version='4.4.12.v20200108-1212'/>
        <provided namespace='java.package' name='org.apache.http.impl' version='4.4.12'/>
        <provided namespace='java.package' name='org.apache.http.impl.bootstrap' version='4.4.12'/>
        <provided namespace='java.package' name='org.apache.http.impl.entity' version='4.4.12'/>
        <provided namespace='java.package' name='org.apache.http.impl.io' version='4.4.12'/>
        <provided namespace='java.package' name='org.apache.http.impl.pool' version='4.4.12'/>
        <provided namespace='java.package' name='org.apache.http' version='4.4.12'/>
        <provided namespace='java.package' name='org.apache.http.annotation' version='4.4.12'/>
        <provided namespace='java.package' name='org.apache.http.concurrent' version='4.4.12'/>
        <provided namespace='java.package' name='org.apache.http.config' version='4.4.12'/>
        <provided namespace='java.package' name='org.apache.http.entity' version='4.4.12'/>
        <provided namespace='java.package' name='org.apache.http.io' version='4.4.12'/>
        <provided namespace='java.package' name='org.apache.http.message' version='4.4.12'/>
        <provided namespace='java.package' name='org.apache.http.params' version='4.4.12'/>
        <provided namespace='java.package' name='org.apache.http.pool' version='4.4.12'/>
        <provided namespace='java.package' name='org.apache.http.protocol' version='4.4.12'/>
        <provided namespace='java.package' name='org.apache.http.ssl' version='4.4.12'/>
        <provided namespace='java.package' name='org.apache.http.util' version='4.4.12'/>
        <provided namespace='osgi.identity' name='org.apache.httpcomponents.httpcore' version='4.4.12.v20200108-1212'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='java.package' name='javax.net' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.net.ssl' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.concurrent' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.config' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.entity' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.impl' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.impl.entity' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.impl.io' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.io' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.message' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.params' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.pool' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.protocol' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.util' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.6))'>
          <description>
            org.apache.httpcomponents.httpcore
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.httpcomponents.httpcore' version='4.4.12.v20200108-1212'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.httpcomponents.httpcore&#xA;Bundle-Version: 4.4.12.v20200108-1212
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.jobs' version='3.10.800.v20200421-0950' generation='2'>
      <update id='org.eclipse.core.jobs' range='[0.0.0,3.10.800.v20200421-0950)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Eclipse Jobs Mechanism'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' version='3.10.800.v20200421-0950'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.jobs' version='3.10.800.v20200421-0950'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.jobs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.jobs' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.jobs' version='3.10.800.v20200421-0950'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.8.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.core.jobs
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.jobs' version='3.10.800.v20200421-0950'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.jobs; singleton:=true&#xA;Bundle-Version: 3.10.800.v20200421-0950
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.jobs.source' version='3.10.800.v20200421-0950' singleton='false'>
      <update id='org.eclipse.core.jobs.source' range='[0.0.0,3.10.800.v20200421-0950)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleVendor' value='Eclipse.org'/>
        <property name='df_LT.bundleName' value='Eclipse Jobs Mechanism Source'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='OSGI-INF/l10n/bundle-src'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs.source' version='3.10.800.v20200421-0950'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.jobs.source' version='3.10.800.v20200421-0950'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.jobs.source' version='3.10.800.v20200421-0950'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='source' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.jobs.source' version='3.10.800.v20200421-0950'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.jobs.source&#xA;Bundle-Version: 3.10.800.v20200421-0950
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.net' version='1.3.900.v20200428-1255' generation='2'>
      <update id='org.eclipse.core.net' range='[0.0.0,1.3.900.v20200428-1255)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.PLUGIN_NAME' value='Internet Connection Management'/>
        <property name='df_LT.PLUGIN_PROVIDER' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%PLUGIN_NAME'/>
        <property name='org.eclipse.equinox.p2.provider' value='%PLUGIN_PROVIDER'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net' version='1.3.900.v20200428-1255'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.net' version='1.3.900.v20200428-1255'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.net' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.net.proxy' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.net' version='1.3.900.v20200428-1255'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.security' range='[1.0.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.12.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='3.2.200'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='3.4.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='3.4.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.core.net
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.net' version='1.3.900.v20200428-1255'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.net;singleton:=true&#xA;Bundle-Version: 1.3.900.v20200428-1255
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf' version='3.10.0.v20210925-0032' generation='2'>
      <update id='org.eclipse.ecf' range='[0.0.0,3.10.0.v20210925-0032)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.plugin.name' value='ECF Core API'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='17'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf' version='3.10.0.v20210925-0032'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf' version='3.10.0.v20210925-0032'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core' version='3.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.events' version='3.1.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.jobs' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.provider' version='3.3.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.security' version='3.1.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.start' version='3.1.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.status' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.user' version='3.1.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.util' version='3.6.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.util.reflection' version='2.3.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.core' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.ecf' version='3.10.0.v20210925-0032'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='ecf.containertype' name='org.eclipse.ecf_3.10.0.v20210925-0032-1' version='3.3.0'>
          <properties size='1'>
            <property name='names' value='ecf.base' type='List'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.0.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.0.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.identity' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.concurrent.future' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.3.2,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.eclipse.ecf
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf' version='3.10.0.v20210925-0032'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ecf;singleton:=true&#xA;Bundle-Version: 3.10.0.v20210925-0032
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.filetransfer' version='5.1.102.v20210409-2301' generation='2'>
      <update id='org.eclipse.ecf.filetransfer' range='[0.0.0,5.1.102.v20210409-2301)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.plugin.name' value='ECF Filetransfer API'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer' version='5.1.102.v20210409-2301'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.filetransfer' version='5.1.102.v20210409-2301'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer' version='5.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer.events' version='5.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer.events.socket' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer.events.socketfactory' version='5.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer.identity' version='5.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer.service' version='5.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.filetransfer' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.ecf.filetransfer' version='5.1.102.v20210409-2301'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.0.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.0.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf' range='[3.0.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.url' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.3.2,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.ecf.filetransfer
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.filetransfer' version='5.1.102.v20210409-2301'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ecf.filetransfer;singleton:=true&#xA;Bundle-Version: 5.1.102.v20210409-2301
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.identity' version='3.9.402.v20210409-2301' generation='2'>
      <update id='org.eclipse.ecf.identity' range='[0.0.0,3.9.402.v20210409-2301)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.plugin.name' value='ECF Identity Core API'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.identity' version='3.9.402.v20210409-2301'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.identity' version='3.9.402.v20210409-2301'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.identity' version='3.3.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.util' version='3.6.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.core.identity' version='3.2.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.ecf.identity' version='3.9.402.v20210409-2301'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='ecf.namespace' name='org.eclipse.ecf.identity_3.9.402.v20210409-2301-1' version='0.0.0'>
          <properties size='1'>
            <property name='names' value='”org.eclipse.ecf.core.identity.StringID' type='List'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.ecf.core.identity.GUID' name='org.eclipse.ecf.identity_3.9.402.v20210409-2301-2' version='0.0.0'/>
        <provided namespace='org.eclipse.ecf.core.identity.LongID' name='org.eclipse.ecf.identity_3.9.402.v20210409-2301-3' version='0.0.0'/>
        <provided namespace='org.eclipse.ecf.core.identity.URIID”' name='org.eclipse.ecf.identity_3.9.402.v20210409-2301-4' version='3.3.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.0.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.0.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.3.2,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.eclipse.ecf.identity
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.identity' version='3.9.402.v20210409-2301'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ecf.identity;singleton:=true&#xA;Bundle-Version: 3.9.402.v20210409-2301
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.provider.filetransfer' version='3.2.800.v20220215-0126' generation='2'>
      <update id='org.eclipse.ecf.provider.filetransfer' range='[0.0.0,3.2.800.v20220215-0126)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.plugin.name' value='ECF Filetransfer Provider'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer' version='3.2.800.v20220215-0126'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer' version='3.2.800.v20220215-0126'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.provider.filetransfer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer' version='3.2.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.browse' version='3.2.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.events.socket' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.identity' version='3.2.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.outgoing' version='3.2.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.retrieve' version='3.2.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.util' version='3.2.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.ecf.provider.filetransfer' version='3.2.800.v20220215-0126'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.0.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf' range='[3.0.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.filetransfer' range='[5.0.0,6.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.0.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.core.net.proxy' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.events.socket' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.url' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.3.2,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.eclipse.ecf.provider.filetransfer
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.provider.filetransfer' version='3.2.800.v20220215-0126'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ecf.provider.filetransfer;singleton:=true&#xA;Bundle-Version: 3.2.800.v20220215-0126
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.provider.filetransfer.httpclient45' version='1.0.300.v20200522-1203' generation='2'>
      <update id='org.eclipse.ecf.provider.filetransfer.httpclient45' range='[0.0.0,1.0.300.v20200522-1203)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.plugin.name' value='ECF HttpComponents 4.5 Filetransfer Provider'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer.httpclient45' version='1.0.300.v20200522-1203'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer.httpclient45' version='1.0.300.v20200522-1203'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.provider.filetransfer.httpclient45' version='0.1.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.httpclient45' version='0.1.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.ecf.provider.filetransfer.httpclient45' version='1.0.300.v20200522-1203'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='27'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.0.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer' range='[3.2.200,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.filetransfer' range='[5.0.0,6.0.0)'/>
        <required namespace='java.package' name='org.apache.http' range='[4.4.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.auth' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.client' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.client.config' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.client.methods' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.client.protocol' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.client.utils' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.config' range='[4.4.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.conn.socket' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.conn.ssl' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.conn.util' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.auth' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.client' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.message' range='[4.4.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.protocol' range='[4.4.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.util' range='[4.4.0,5.0.0)'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.2.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'>
          <description>
            org.eclipse.ecf.provider.filetransfer.httpclient45
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.provider.filetransfer.httpclient45' version='1.0.300.v20200522-1203'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ecf.provider.filetransfer.httpclient45;singleton:=true&#xA;Bundle-Version: 1.0.300.v20200522-1203
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.provider.filetransfer.ssl' version='1.0.201.v20210409-2301' singleton='false' generation='2'>
      <update id='org.eclipse.ecf.provider.filetransfer.ssl' range='[0.0.0,1.0.201.v20210409-2301)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.plugin.name' value='ECF Filetransfer SSL Fragment'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer.ssl' version='1.0.201.v20210409-2301'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer.ssl' version='1.0.201.v20210409-2301'/>
        <provided namespace='osgi.identity' name='org.eclipse.ecf.provider.filetransfer.ssl' version='1.0.201.v20210409-2301'>
          <properties size='1'>
            <property name='type' value='osgi.fragment'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.ecf.provider.filetransfer' version='1.0.201.v20210409-2301'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer' range='2.0.0'/>
        <required namespace='java.package' name='javax.net.ssl' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.eclipse.ecf.provider.filetransfer.ssl
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.provider.filetransfer.ssl' version='1.0.201.v20210409-2301'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ecf.provider.filetransfer.ssl&#xA;Bundle-Version: 1.0.201.v20210409-2301&#xA;Fragment-Host: org.eclipse.ecf.provider.filetransfer;bundle-version=&quot;2.0.0&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.ssl' version='1.2.401.v20210409-2301' singleton='false' generation='2'>
      <update id='org.eclipse.ecf.ssl' range='[0.0.0,1.2.401.v20210409-2301)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.plugin.name' value='ECF SSL Fragment'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.ssl' version='1.2.401.v20210409-2301'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.ssl' version='1.2.401.v20210409-2301'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.ssl' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.ecf.ssl' version='1.2.401.v20210409-2301'>
          <properties size='1'>
            <property name='type' value='osgi.fragment'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.ecf' version='1.2.401.v20210409-2301'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.ecf' range='0.0.0'/>
        <required namespace='java.package' name='javax.net' range='0.0.0'/>
        <required namespace='java.package' name='javax.net.ssl' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.security' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.eclipse.ecf.ssl
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.ssl' version='1.2.401.v20210409-2301'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ecf.ssl&#xA;Bundle-Version: 1.2.401.v20210409-2301&#xA;Fragment-Host: org.eclipse.ecf
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.app' version='1.4.500.v20200422-1833' generation='2'>
      <update id='org.eclipse.equinox.app' range='[0.0.0,1.4.500.v20200422-1833)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Application Container'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' version='1.4.500.v20200422-1833'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.app' version='1.4.500.v20200422-1833'/>
        <provided namespace='java.package' name='org.eclipse.equinox.app' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.app' version='0.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.application' version='1.1.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.app' version='1.4.500.v20200422-1833'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.runnable' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.storagemanager' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.condpermadmin' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'>
          <description>
            org.eclipse.equinox.app
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.app' version='1.4.500.v20200422-1833'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.app; singleton:=true&#xA;Bundle-Version: 1.4.500.v20200422-1833
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.common' version='3.12.0.v20200504-1602' generation='2'>
      <update id='org.eclipse.equinox.common' range='[0.0.0,3.12.0.v20200504-1602)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Common Eclipse Runtime'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' version='3.12.0.v20200504-1602'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.common' version='3.12.0.v20200504-1602'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.boot' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.5.0'/>
        <provided namespace='java.package' name='org.eclipse.core.text' version='3.12.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.events' version='1.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.common' version='3.12.0.v20200504-1602'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='java.package' name='org.eclipse.equinox.log' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.urlconversion' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.url' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.common
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.common' version='3.12.0.v20200504-1602'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.common; singleton:=true&#xA;Bundle-Version: 3.12.0.v20200504-1602
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.concurrent' version='1.1.500.v20200106-1437' singleton='false' generation='2'>
      <update id='org.eclipse.equinox.concurrent' range='[0.0.0,1.1.500.v20200106-1437)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Concurrent API'/>
        <property name='df_LT.pluginProvider' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%pluginProvider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.concurrent' version='1.1.500.v20200106-1437'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.concurrent' version='1.1.500.v20200106-1437'/>
        <provided namespace='java.package' name='org.eclipse.equinox.concurrent.future' version='1.1.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.concurrent' version='1.1.500.v20200106-1437'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='java.package' name='org.eclipse.core.runtime' range='3.4.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.eclipse.equinox.concurrent
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.concurrent' version='1.1.500.v20200106-1437'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.concurrent&#xA;Bundle-Version: 1.1.500.v20200106-1437
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.frameworkadmin' version='2.1.400.v20191002-0702' generation='2'>
      <update id='org.eclipse.equinox.frameworkadmin' range='[0.0.0,2.1.400.v20191002-0702)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Framework Admin'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin' version='2.1.400.v20191002-0702'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.frameworkadmin' version='2.1.400.v20191002-0702'/>
        <provided namespace='java.package' name='org.eclipse.equinox.frameworkadmin' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.utils' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.configuratormanipulator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.frameworkadmin' version='2.1.400.v20191002-0702'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.4.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.pluginconversion' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.frameworkadmin
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.frameworkadmin' version='2.1.400.v20191002-0702'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.frameworkadmin;singleton:=true&#xA;Bundle-Version: 2.1.400.v20191002-0702
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.frameworkadmin.equinox' version='1.1.400.v20200319-1546' generation='2'>
      <update id='org.eclipse.equinox.frameworkadmin.equinox' range='[0.0.0,1.1.400.v20200319-1546)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Framework Admin for Equinox'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox' version='1.1.400.v20200319-1546'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.frameworkadmin.equinox' version='1.1.400.v20200319-1546'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.equinox' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.equinox.utils' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.frameworkadmin.equinox' version='1.1.400.v20200319-1546'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.frameworkadmin' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.utils' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.configuratormanipulator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.1.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.frameworkadmin.equinox
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.frameworkadmin.equinox' version='1.1.400.v20200319-1546'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.frameworkadmin.equinox;singleton:=true&#xA;Bundle-Version: 1.1.400.v20200319-1546
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.artifact.repository' version='1.3.500.v20200406-2025' generation='2'>
      <update id='org.eclipse.equinox.p2.artifact.repository' range='[0.0.0,1.3.500.v20200406-2025)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Artifact Repository Support'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository' version='1.3.500.v20200406-2025'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.artifact.repository' version='1.3.500.v20200406-2025'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processors.checksum' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processors.md5' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processors.pack200' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.artifact.repository.processing' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.artifact.repository' version='1.3.500.v20200406-2025'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='29'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.tukaani.xz' range='1.3.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.internal.provisional.equinox.p2.jarprocessor' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.signedcontent' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.1.1'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.p2.artifact.repository
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.artifact.repository' version='1.3.500.v20200406-2025'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.artifact.repository;singleton:=true&#xA;Bundle-Version: 1.3.500.v20200406-2025
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.core' version='2.6.300.v20200211-1504' generation='2'>
      <update id='org.eclipse.equinox.p2.core' range='[0.0.0,2.6.300.v20200211-1504)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Core'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core' version='2.6.300.v20200211-1504'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.core' version='2.6.300.v20200211-1504'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.core' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.core.spi' version='2.1.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.core' version='2.6.300.v20200211-1504'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' range='1.2.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.5.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.p2.core
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.core' version='2.6.300.v20200211-1504'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.core;singleton:=true&#xA;Bundle-Version: 2.6.300.v20200211-1504
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.director' version='2.4.700.v20200511-1530' generation='2'>
      <update id='org.eclipse.equinox.p2.director' range='[0.0.0,2.4.700.v20200511-1530)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Director'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director' version='2.4.700.v20200511-1530'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.director' version='2.4.700.v20200511-1530'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.director' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.rollback' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.director' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.planner' version='2.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.director' version='2.4.700.v20200511-1530'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.sat4j.core' range='[2.3.5,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.sat4j.pb' range='[2.3.5,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.configurator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.p2.director
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.director' version='2.4.700.v20200511-1530'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.director;singleton:=true&#xA;Bundle-Version: 2.4.700.v20200511-1530
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.director.app' version='1.1.600.v20200511-1530' generation='2'>
      <update id='org.eclipse.equinox.p2.director.app' range='[0.0.0,1.1.600.v20200511-1530)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Director Application'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director.app' version='1.1.600.v20200511-1530'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.director.app' version='1.1.600.v20200511-1530'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.director.app' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.director.app' version='1.1.600.v20200511-1530'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='25'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.director' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.engine' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.director' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.planner' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.p2.director.app
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.director.app' version='1.1.600.v20200511-1530'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.director.app;singleton:=true&#xA;Bundle-Version: 1.1.600.v20200511-1530
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.engine' version='2.6.700.v20200511-1530' generation='2'>
      <update id='org.eclipse.equinox.p2.engine' range='[0.0.0,2.6.700.v20200511-1530)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Engine'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine' version='2.6.700.v20200511-1530'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.engine' version='2.6.700.v20200511-1530'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.engine' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.engine.phases' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.engine' version='2.2.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.engine.query' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.engine.spi' version='2.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.engine' version='2.6.700.v20200511-1530'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='35'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.4.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.internal.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository.io' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.security' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.signedcontent' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.p2.engine
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.engine' version='2.6.700.v20200511-1530'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.engine;singleton:=true&#xA;Bundle-Version: 2.6.700.v20200511-1530
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.garbagecollector' version='1.1.400.v20200221-1022' generation='2'>
      <update id='org.eclipse.equinox.p2.garbagecollector' range='[0.0.0,1.1.400.v20200221-1022)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Garbage Collector'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector' version='1.1.400.v20200221-1022'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.garbagecollector' version='1.1.400.v20200221-1022'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.garbagecollector' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.garbagecollector' version='1.1.400.v20200221-1022'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.engine' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.4.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.2.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.1.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.p2.garbagecollector
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.garbagecollector' version='1.1.400.v20200221-1022'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.garbagecollector;singleton:=true&#xA;Bundle-Version: 1.1.400.v20200221-1022
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.jarprocessor' version='1.1.600.v20200217-1130' generation='2'>
      <update id='org.eclipse.equinox.p2.jarprocessor' range='[0.0.0,1.1.600.v20200217-1130)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning JAR Processor'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor' version='1.1.600.v20200217-1130'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.jarprocessor' version='1.1.600.v20200217-1130'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor.unsigner' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor.verifier' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.internal.provisional.equinox.p2.jarprocessor' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.jarprocessor' version='1.1.600.v20200217-1130'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.3.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.p2.jarprocessor
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.jarprocessor' version='1.1.600.v20200217-1130'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.jarprocessor;singleton:=true&#xA;Bundle-Version: 1.1.600.v20200217-1130
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.metadata' version='2.5.0.v20200511-1530' generation='2'>
      <update id='org.eclipse.equinox.p2.metadata' range='[0.0.0,2.5.0.v20200511-1530)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Metadata'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata' version='2.5.0.v20200511-1530'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' version='2.5.0.v20200511-1530'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.expression' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.expression.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.query' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata' version='2.4.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.query' version='2.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.metadata' version='2.5.0.v20200511-1530'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.p2.metadata
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.metadata' version='2.5.0.v20200511-1530'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.metadata;singleton:=true&#xA;Bundle-Version: 2.5.0.v20200511-1530
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.metadata.repository' version='1.3.400.v20191211-1528' generation='2'>
      <update id='org.eclipse.equinox.p2.metadata.repository' range='[0.0.0,1.3.400.v20191211-1528)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Metadata Repository'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository' version='1.3.400.v20191211-1528'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata.repository' version='1.3.400.v20191211-1528'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository.io' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata.io' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.metadata.repository' version='1.3.400.v20191211-1528'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='27'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.tukaani.xz' range='1.3.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.1.1'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.p2.metadata.repository
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.metadata.repository' version='1.3.400.v20191211-1528'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.metadata.repository;singleton:=true&#xA;Bundle-Version: 1.3.400.v20191211-1528
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.publisher' version='1.5.400.v20200511-1530' generation='2'>
      <update id='org.eclipse.equinox.p2.publisher' range='[0.0.0,1.5.400.v20200511-1530)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleName' value='Equinox Provisioning Publisher Infrastructure'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher' version='1.5.400.v20200511-1530'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.publisher' version='1.5.400.v20200511-1530'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.publisher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.publisher.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.spi.p2.publisher' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.publisher' version='1.5.400.v20200511-1530'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='26'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='3.8.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processors.checksum' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.expression' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.2.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.application' range='1.1.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.p2.publisher
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.publisher' version='1.5.400.v20200511-1530'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.publisher;singleton:=true&#xA;Bundle-Version: 1.5.400.v20200511-1530
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.publisher.eclipse' version='1.3.600.v20200318-1507' generation='2'>
      <update id='org.eclipse.equinox.p2.publisher.eclipse' range='[0.0.0,1.3.600.v20200318-1507)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleName' value='Equinox Provisioning Publisher for Eclipse'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse' version='1.3.600.v20200318-1507'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.publisher.eclipse' version='1.3.600.v20200318-1507'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher.compatibility' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher.eclipse' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.publisher.eclipse' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.pde.internal.build.publisher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.pde.internal.publishing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.pde.internal.swt.tools' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.publisher.eclipse' version='1.3.600.v20200318-1507'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='37'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.frameworkadmin' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.equinox' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.utils' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.actions' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.simpleconfigurator.manipulator' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.spi.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.util' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.3.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.pluginconversion' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.5.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.resource' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.application' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.p2.publisher.eclipse
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.publisher.eclipse' version='1.3.600.v20200318-1507'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.publisher.eclipse;singleton:=true&#xA;Bundle-Version: 1.3.600.v20200318-1507
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.repository' version='2.4.700.v20200110-2121' generation='2'>
      <update id='org.eclipse.equinox.p2.repository' range='[0.0.0,2.4.700.v20200110-2121)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Repository'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository' version='2.4.700.v20200110-2121'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.repository' version='2.4.700.v20200110-2121'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' version='2.3.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' version='2.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.repository' version='2.4.700.v20200110-2121'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='26'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='3.3.0'/>
        <required namespace='java.package' name='javax.crypto' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='3.2.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.security.storage' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.p2.repository
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.repository' version='2.4.700.v20200110-2121'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.repository;singleton:=true&#xA;Bundle-Version: 2.4.700.v20200110-2121
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.2.600.v20200114-1339' generation='2'>
      <update id='org.eclipse.equinox.p2.touchpoint.eclipse' range='[0.0.0,2.2.600.v20200114-1339)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Eclipse Touchpoint'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.2.600.v20200114-1339'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.2.600.v20200114-1339'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.touchpoint.eclipse' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.touchpoint.eclipse.actions' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.update' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.touchpoint.eclipse.query' version='2.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.2.600.v20200114-1339'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='35'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.frameworkadmin' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.engine' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.garbagecollector' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.manipulator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.planner' range='[2.0.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.eclipse' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.3.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.simpleconfigurator.manipulator' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.2.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.1.1'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.p2.touchpoint.eclipse
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.2.600.v20200114-1339'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.touchpoint.eclipse;singleton:=true&#xA;Bundle-Version: 2.2.600.v20200114-1339
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.touchpoint.natives' version='1.3.600.v20200511-1530' generation='2'>
      <update id='org.eclipse.equinox.p2.touchpoint.natives' range='[0.0.0,1.3.600.v20200511-1530)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Native Touchpoint'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='17'>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.2.200.v20200511-1530'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.3.500.v20200511-1530'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.2.100.v20200511-1530'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.3.400.v20200511-1530'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.2.0.v20200511-1530'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.3.600.v20200511-1530'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.touchpoint.natives' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.touchpoint.natives.actions' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.3.300.v20200511-1530'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.3.200.v20200511-1530'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.3.100.v20200511-1530'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.1.100.v20140523-0116'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.3.0.v20200511-1530'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.3.600.v20200511-1530'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.3.600.v20200511-1530'/>
      </provides>
      <requires size='17'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.app' range='1.3.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.engine' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='2.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='2.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.3.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.p2.touchpoint.natives
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.touchpoint.natives' version='1.3.600.v20200511-1530'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.touchpoint.natives;singleton:=true&#xA;Bundle-Version: 1.3.600.v20200511-1530
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.transport.ecf' version='1.2.400.v20200123-2221' singleton='false' generation='2'>
      <update id='org.eclipse.equinox.p2.transport.ecf' range='[0.0.0,1.2.400.v20200123-2221)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning ECF based Transport'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.transport.ecf' version='1.2.400.v20200123-2221'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.transport.ecf' version='1.2.400.v20200123-2221'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.transport.ecf' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.transport.ecf' version='1.2.400.v20200123-2221'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.ecf' range='3.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.filetransfer' range='4.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer' range='3.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.core' range='2.0.100'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.repository' range='2.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.6.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='3.5.100'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.5.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.p2.transport.ecf
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.transport.ecf' version='1.2.400.v20200123-2221'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.transport.ecf&#xA;Bundle-Version: 1.2.400.v20200123-2221
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.updatesite' version='1.1.400.v20200511-1530' generation='2'>
      <update id='org.eclipse.equinox.p2.updatesite' range='[0.0.0,1.1.400.v20200511-1530)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Legacy Update Site Support'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.updatesite' version='1.1.400.v20200511-1530'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.updatesite' version='1.1.400.v20200511-1530'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.updatesite' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.updatesite.artifact' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.updatesite.metadata' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.updatesite' version='1.1.400.v20200511-1530'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='31'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata.repository' range='0.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.artifact.repository' range='0.1.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher.eclipse' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.actions' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.eclipse' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.spi.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.2.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.p2.updatesite
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.updatesite' version='1.1.400.v20200511-1530'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.updatesite;singleton:=true&#xA;Bundle-Version: 1.1.400.v20200511-1530
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.preferences' version='3.8.0.v20200422-1833' generation='2'>
      <update id='org.eclipse.equinox.preferences' range='[0.0.0,3.8.0.v20200422-1833)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Eclipse Preferences Mechanism'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' version='3.8.0.v20200422-1833'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.preferences' version='3.8.0.v20200422-1833'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences.exchange' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.preferences' version='3.4.0'/>
        <provided namespace='java.package' name='org.osgi.service.prefs' version='1.1.1'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.preferences' version='3.8.0.v20200422-1833'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='[1.1.1,1.2.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.preferences
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.preferences' version='3.8.0.v20200422-1833'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.preferences; singleton:=true&#xA;Bundle-Version: 3.8.0.v20200422-1833
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.registry' version='3.8.800.v20200406-0956' generation='2'>
      <update id='org.eclipse.equinox.registry' range='[0.0.0,3.8.800.v20200406-0956)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Extension Registry Support'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' version='3.8.800.v20200406-0956'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.registry' version='3.8.800.v20200406-0956'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.adapter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.osgi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.spi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.5.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.dynamichelpers' version='3.4.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.spi' version='3.4.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.registry' version='3.8.800.v20200406-0956'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.7.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.storagemanager' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.registry
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.registry' version='3.8.800.v20200406-0956'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.registry;singleton:=true&#xA;Bundle-Version: 3.8.800.v20200406-0956
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.security' version='1.3.500.v20200114-1637' generation='2'>
      <update id='org.eclipse.equinox.security' range='[0.0.0,1.3.500.v20200114-1637)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Java Authentication and Authorization Service (JAAS)'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='18'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security' version='1.3.500.v20200114-1637'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.security' version='1.3.500.v20200114-1637'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth.ext.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth.nls' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.credentials' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.storage' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.storage.friends' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.storage.provider' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.auth' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.auth.credentials' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.auth.module' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.storage' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.storage.provider' version='1.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.security' version='1.3.500.v20200114-1637'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='19'>
        <required namespace='java.package' name='javax.crypto' range='0.0.0'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.callback' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.login' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.spi' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.internal.runtime' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.4.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.3.3,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.security
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.security' version='1.3.500.v20200114-1637'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.security;singleton:=true&#xA;Bundle-Version: 1.3.500.v20200114-1637
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.simpleconfigurator' version='1.3.500.v20200211-1505' generation='2'>
      <update id='org.eclipse.equinox.simpleconfigurator' range='[0.0.0,1.3.500.v20200211-1505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleName' value='Simple Configurator'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator' version='1.3.500.v20200211-1505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator' version='1.3.500.v20200211-1505'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.configurator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.console' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.utils' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.simpleconfigurator' version='1.3.500.v20200211-1505'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.framework.namespace' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.resource' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.simpleconfigurator
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.simpleconfigurator' version='1.3.500.v20200211-1505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.simpleconfigurator;singleton:=true&#xA;Bundle-Version: 1.3.500.v20200211-1505
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.1.500.v20200211-1505' generation='2'>
      <update id='org.eclipse.equinox.simpleconfigurator.manipulator' range='[0.0.0,2.1.500.v20200211-1505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleName' value='Simple Configurator Manipulator'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.1.500.v20200211-1505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.1.500.v20200211-1505'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.manipulator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.1.500.v20200211-1505'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.5.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.frameworkadmin' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.equinox' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.utils' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.configuratormanipulator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.utils' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.simpleconfigurator.manipulator
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.1.500.v20200211-1505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.simpleconfigurator.manipulator;singleton:=true&#xA;Bundle-Version: 2.1.500.v20200211-1505
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi' version='3.15.300.v20200520-1959' generation='2'>
      <update id='org.eclipse.osgi' range='[0.0.0,3.15.300.v20200520-1959)' severity='0'/>
      <properties size='7'>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='df_LT.systemBundle' value='OSGi System Bundle'/>
        <property name='org.eclipse.equinox.p2.name' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.description' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='systembundle'/>
      </properties>
      <provides size='92'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' version='3.15.300.v20200520-1959'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi' version='3.15.300.v20200520-1959'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.internal.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.log' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.container' version='1.5.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.container.builders' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.container.namespaces' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.console' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.reliablefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.log' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.debug' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.framework' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.hookregistry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.buddy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.classpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.sources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.location' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.messages' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.verifier' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.service.security' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.serviceregistry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.signedcontent' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.url' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.launch' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.report.resolution' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.datalocation' version='1.3.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.debug' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.environment' version='1.4.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.localization' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.pluginconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.resolver' version='1.6.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.runnable' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.urlconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.signedcontent' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage.bundlefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage.url.reference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storagemanager' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.util' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.dto' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework' version='1.9.0'/>
        <provided namespace='java.package' name='org.osgi.framework.dto' version='1.8.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.bundle' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.resolver' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.service' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.weaving' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.launch' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.framework.namespace' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.startlevel' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.startlevel.dto' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.wiring' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.framework.wiring.dto' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.resource' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.resource.dto' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.condpermadmin' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.service.log' version='1.4.0'/>
        <provided namespace='java.package' name='org.osgi.service.log.admin' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.packageadmin' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.permissionadmin' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.resolver' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.startlevel' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.url' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.util.tracker' version='1.5.2'/>
        <provided namespace='osgi.identity' name='org.eclipse.osgi' version='3.15.300.v20200520-1959'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.15.300.v20200520-1959-1' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.log.LogReaderService,org.eclipse.equinox.log.ExtendedLogReaderService' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.15.300.v20200520-1959-2' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.log.LoggerFactory,org.osgi.service.log.LogService,org.eclipse.equinox.log.ExtendedLogService' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.15.300.v20200520-1959-3' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.log.admin.LoggerAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.15.300.v20200520-1959-4' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.framework.log.FrameworkLog' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.15.300.v20200520-1959-5' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.user.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.15.300.v20200520-1959-6' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.instance.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.15.300.v20200520-1959-7' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.configuration.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.15.300.v20200520-1959-8' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.install.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.15.300.v20200520-1959-9' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='eclipse.home.location'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.15.300.v20200520-1959-10' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.environment.EnvironmentInfo' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.15.300.v20200520-1959-11' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.packageadmin.PackageAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.15.300.v20200520-1959-12' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.startlevel.StartLevel' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.15.300.v20200520-1959-13' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.permissionadmin.PermissionAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.15.300.v20200520-1959-14' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.condpermadmin.ConditionalPermissionAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.15.300.v20200520-1959-15' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.resolver.Resolver' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.15.300.v20200520-1959-16' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.debug.DebugOptions' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.15.300.v20200520-1959-17' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.urlconversion.URLConverter' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.15.300.v20200520-1959-18' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.localization.BundleLocalization' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.15.300.v20200520-1959-19' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.security.TrustEngine' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.15.300.v20200520-1959-20' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.signedcontent.SignedContentFactory' type='List'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(|(&amp;(osgi.ee=JavaSE)(version=1.7))(&amp;(osgi.ee=JavaSE/compact1)(version=1.8)))'>
          <description>
            org.eclipse.osgi
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi' version='3.15.300.v20200520-1959'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi; singleton:=true&#xA;Bundle-Version: 3.15.300.v20200520-1959
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi.compatibility.state' version='1.1.800.v20200511-1223' singleton='false' generation='2'>
      <update id='org.eclipse.osgi.compatibility.state' range='[0.0.0,1.1.800.v20200511-1223)' severity='0'/>
      <properties size='4'>
        <property name='df_LT.Bundle-Name' value='Equinox State and Resolver Compatibility Fragment'/>
        <property name='df_LT.Bundle-Vendor' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state' version='1.1.800.v20200511-1223'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi.compatibility.state' version='1.1.800.v20200511-1223'/>
        <provided namespace='osgi.identity' name='org.eclipse.osgi.compatibility.state' version='1.1.800.v20200511-1223'>
          <properties size='1'>
            <property name='type' value='osgi.fragment'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.osgi' version='1.1.800.v20200511-1223'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='3.12.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'>
          <description>
            org.eclipse.osgi.compatibility.state
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi.compatibility.state' version='1.1.800.v20200511-1223'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi.compatibility.state&#xA;Bundle-Version: 1.1.800.v20200511-1223&#xA;Fragment-Host: org.eclipse.osgi;bundle-version=&quot;3.12.0&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi.services' version='3.8.0.v20190206-2147' singleton='false' generation='2'>
      <update id='org.eclipse.osgi.services' range='[0.0.0,3.8.0.v20190206-2147)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.osgiServicesDes' value='OSGi Service Platform Release 4.2.0 Service Interfaces and Classes'/>
        <property name='df_LT.osgiServices' value='OSGi Release 4.2.0 Services'/>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%osgiServices'/>
        <property name='org.eclipse.equinox.p2.description' value='%osgiServicesDes'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.contact' value='www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='23'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services' version='3.8.0.v20190206-2147'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi.services' version='3.8.0.v20190206-2147'/>
        <provided namespace='java.package' name='org.osgi.service.cm' version='1.6.0'/>
        <provided namespace='java.package' name='org.osgi.service.component' version='1.4.0'/>
        <provided namespace='java.package' name='org.osgi.service.component.annotations' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.component.runtime' version='1.4.0'/>
        <provided namespace='java.package' name='org.osgi.service.component.runtime.dto' version='1.4.0'/>
        <provided namespace='java.package' name='org.osgi.service.device' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.event' version='1.4.0'/>
        <provided namespace='java.package' name='org.osgi.service.http' version='1.2.1'/>
        <provided namespace='java.package' name='org.osgi.service.http.context' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.http.runtime' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.http.runtime.dto' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.http.whiteboard' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.log' version='1.4.0'/>
        <provided namespace='java.package' name='org.osgi.service.metatype' version='1.4.0'/>
        <provided namespace='java.package' name='org.osgi.service.provisioning' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.upnp' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.useradmin' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.wireadmin' version='1.0.1'/>
        <provided namespace='osgi.identity' name='org.eclipse.osgi.services' version='3.8.0.v20190206-2147'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='26'>
        <required namespace='java.package' name='org.osgi.service.http.whiteboard' range='[1.1.0,1.2.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'>
          <description>
            org.eclipse.osgi.services
          </description>
        </requiredProperties>
        <required namespace='java.package' name='org.osgi.service.component.runtime.dto' range='[1.4.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.service.http.runtime' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='javax.servlet.http' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.cm' range='[1.6.0,1.7.0)'/>
        <required namespace='java.package' name='org.osgi.service.component' range='[1.4.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.framework.dto' range='1.8.0'/>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.4.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.service.wireadmin' range='[1.0.0,1.1.0)'/>
        <required namespace='java.package' name='org.osgi.dto' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.http' range='[1.2.0,1.3.0)'/>
        <required namespace='java.package' name='org.osgi.service.device' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.service.http.context' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.util.promise' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='javax.servlet' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.useradmin' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.service.metatype' range='[1.4.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.service.http.runtime.dto' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.service.provisioning' range='[1.2.0,1.3.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.annotations' range='[1.3.0,1.4.0)'/>
        <required namespace='java.package' name='org.osgi.service.upnp' range='[1.2.0,1.3.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime' range='[1.4.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.util.function' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.4.0,1.5.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi.services' version='3.8.0.v20190206-2147'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi.services&#xA;Bundle-Version: 3.8.0.v20190206-2147
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi.util' version='3.5.300.v20190708-1141' singleton='false' generation='2'>
      <update id='org.eclipse.osgi.util' range='[0.0.0,3.5.300.v20190708-1141)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.osgiUtilDes' value='OSGi Service Platform Release 4.2.0 Utility Classes'/>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='df_LT.osgiUtil' value='OSGi Release 4.2.0 Utility Classes'/>
        <property name='org.eclipse.equinox.p2.name' value='%osgiUtil'/>
        <property name='org.eclipse.equinox.p2.description' value='%osgiUtilDes'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.contact' value='www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.util' version='3.5.300.v20190708-1141'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi.util' version='3.5.300.v20190708-1141'/>
        <provided namespace='java.package' name='org.osgi.util.function' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.util.measurement' version='1.0.2'/>
        <provided namespace='java.package' name='org.osgi.util.position' version='1.0.1'/>
        <provided namespace='java.package' name='org.osgi.util.promise' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.util.xml' version='1.0.1'/>
        <provided namespace='osgi.identity' name='org.eclipse.osgi.util' version='3.5.300.v20190708-1141'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='java.package' name='org.osgi.framework' range='1.1.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.function' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.util.measurement' range='[1.0.2,1.1.0)'/>
        <required namespace='java.package' name='org.osgi.util.position' range='[1.0.1,1.1.0)'/>
        <required namespace='java.package' name='org.osgi.util.promise' range='[1.1.1,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.util.xml' range='[1.0.1,1.1.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'>
          <description>
            org.eclipse.osgi.util
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi.util' version='3.5.300.v20190708-1141'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi.util&#xA;Bundle-Version: 3.5.300.v20190708-1141
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.sat4j.core' version='2.3.5.v201308161310' singleton='false' generation='2'>
      <update id='org.sat4j.core' range='[0.0.0,2.3.5.v201308161310)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleName' value='SAT4J Core'/>
        <property name='df_LT.providerName' value='Eclipse Orbit'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='21'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.core' version='2.3.5.v201308161310'/>
        <provided namespace='osgi.bundle' name='org.sat4j.core' version='2.3.5.v201308161310'/>
        <provided namespace='java.package' name='org.sat4j' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.core' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat.constraints' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat.constraints.card' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat.constraints.cnf' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat.core' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat.learning' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat.orders' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat.restarts' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.opt' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.reader' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.specs' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.tools' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.tools.encoding' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.tools.xplain' version='2.3.5.v20130525'/>
        <provided namespace='osgi.identity' name='org.sat4j.core' version='2.3.5.v201308161310'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.sat4j.core
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.sat4j.core' version='2.3.5.v201308161310'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.sat4j.core&#xA;Bundle-Version: 2.3.5.v201308161310
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.sat4j.pb' version='2.3.5.v201404071733' singleton='false' generation='2'>
      <update id='org.sat4j.pb' range='[0.0.0,2.3.5.v201404071733)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleName' value='SAT4J Pseudo'/>
        <property name='df_LT.providerName' value='Eclipse Orbit'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.pb' version='2.3.5.v201404071733'/>
        <provided namespace='osgi.bundle' name='org.sat4j.pb' version='2.3.5.v201404071733'/>
        <provided namespace='java.package' name='org.sat4j.pb' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.pb.constraints' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.pb.constraints.pb' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.pb.core' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.pb.orders' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.pb.reader' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.pb.tools' version='2.3.5.v20130525'/>
        <provided namespace='osgi.identity' name='org.sat4j.pb' version='2.3.5.v201404071733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.sat4j.core' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.sat4j.pb
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.sat4j.pb' version='2.3.5.v201404071733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.sat4j.pb&#xA;Bundle-Version: 2.3.5.v201404071733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.sonatype.p2.runtime' version='1.0.0'>
      <update id='org.sonatype.p2.runtime' range='0.0.0' severity='0'/>
      <properties size='3'>
        <property name='org.eclipse.equinox.p2.name' value='Sonatype P2 Fork Runtime'/>
        <property name='org.eclipse.equinox.p2.type.product' value='true'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.sonatype.p2.runtime' version='1.0.0'/>
      </provides>
      <requires size='57'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.scr' range='[2.1.16.v20200110-1820,2.1.16.v20200110-1820]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin' range='[2.1.400.v20191002-0702,2.1.400.v20191002-0702]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs.source' range='[3.10.800.v20200421-0950,3.10.800.v20200421-0950]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.transport.ecf' range='[1.2.400.v20200123-2221,1.2.400.v20200123-2221]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.httpcomponents.httpclient' range='[4.5.10.v20200114-1512,4.5.10.v20200114-1512]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata' range='[2.5.0.v20200511-1530,2.5.0.v20200511-1530]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse' range='[2.2.600.v20200114-1339,2.2.600.v20200114-1339]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf' range='[3.10.0.v20210925-0032,3.10.0.v20210925-0032]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.updatesite' range='[1.1.400.v20200511-1530,1.1.400.v20200511-1530]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net' range='[1.3.900.v20200428-1255,1.3.900.v20200428-1255]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' range='[1.3.600.v20200511-1530,1.3.600.v20200511-1530]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator' range='[2.1.500.v20200211-1505,2.1.500.v20200211-1505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state' range='[1.1.800.v20200511-1223,1.1.800.v20200511-1223]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox' range='[1.1.400.v20200319-1546,1.1.400.v20200319-1546]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer.httpclient45' range='[1.0.300.v20200522-1203,1.0.300.v20200522-1203]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.util' range='[3.5.300.v20190708-1141,3.5.300.v20190708-1141]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository' range='[2.4.700.v20200110-2121,2.4.700.v20200110-2121]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' range='[3.8.0.v20200422-1833,3.8.0.v20200422-1833]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core' range='[2.6.300.v20200211-1504,2.6.300.v20200211-1504]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator' range='[1.3.500.v20200211-1505,1.3.500.v20200211-1505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.logging' range='[1.2.0.v20180409-1502,1.2.0.v20180409-1502]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.core' range='[2.3.5.v201308161310,2.3.5.v201308161310]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.httpclient' range='[3.1.0.v201012070820,3.1.0.v201012070820]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director.app' range='[1.1.600.v20200511-1530,1.1.600.v20200511-1530]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse' range='[1.3.600.v20200318-1507,1.3.600.v20200318-1507]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository' range='[1.3.400.v20191211-1528,1.3.400.v20191211-1528]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher' range='[1.5.400.v20200511-1530,1.5.400.v20200511-1530]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security' range='[1.3.500.v20200114-1637,1.3.500.v20200114-1637]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.pb' range='[2.3.5.v201404071733,2.3.5.v201404071733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='javax.xml' range='[1.3.4.v201005080400,1.3.4.v201005080400]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer.ssl' range='[1.0.201.v20210409-2301,1.0.201.v20210409-2301]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.concurrent' range='[1.1.500.v20200106-1437,1.1.500.v20200106-1437]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.identity' range='[3.9.402.v20210409-2301,3.9.402.v20210409-2301]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.httpcomponents.httpcore' range='[4.4.12.v20200108-1212,4.4.12.v20200108-1212]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository' range='[1.3.500.v20200406-2025,1.3.500.v20200406-2025]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.sonatype.p2.runtime.configuration' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' range='[3.12.0.v20200504-1602,3.12.0.v20200504-1602]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services' range='[3.8.0.v20190206-2147,3.8.0.v20190206-2147]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.ssl' range='[1.2.401.v20210409-2301,1.2.401.v20210409-2301]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' range='[3.8.800.v20200406-0956,3.8.800.v20200406-0956]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.jcraft.jsch' range='[0.1.55.v20190404-1902,0.1.55.v20190404-1902]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.codec' range='[1.13.0.v20200108-0001,1.13.0.v20200108-0001]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' range='[3.10.800.v20200421-0950,3.10.800.v20200421-0950]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer' range='[3.2.800.v20220215-0126,3.2.800.v20220215-0126]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer' range='[5.1.102.v20210409-2301,5.1.102.v20210409-2301]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine' range='[2.6.700.v20200511-1530,2.6.700.v20200511-1530]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director' range='[2.4.700.v20200511-1530,2.4.700.v20200511-1530]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.tukaani.xz' range='[1.8.0.v20180207-1613,1.8.0.v20180207-1613]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='javax.servlet' range='[3.1.0.v201410161800,3.1.0.v201410161800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector' range='[1.1.400.v20200221-1022,1.1.400.v20200221-1022]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor' range='[1.1.600.v20200217-1130,1.1.600.v20200217-1130]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' range='[3.15.300.v20200520-1959,3.15.300.v20200520-1959]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' range='[1.4.500.v20200422-1833,1.4.500.v20200422-1833]'/>
        <required namespace='osgi.ee' name='JavaSE' range='0.0.0'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
    </unit>
    <unit id='org.tukaani.xz' version='1.8.0.v20180207-1613' singleton='false' generation='2'>
      <update id='org.tukaani.xz' range='[0.0.0,1.8.0.v20180207-1613)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='XZ for Java'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://tukaani.org/xz/java.html'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.tukaani.xz' version='1.8.0.v20180207-1613'/>
        <provided namespace='osgi.bundle' name='org.tukaani.xz' version='1.8.0.v20180207-1613'/>
        <provided namespace='java.package' name='org.tukaani.xz' version='1.8.0'/>
        <provided namespace='java.package' name='org.tukaani.xz.check' version='1.8.0'/>
        <provided namespace='java.package' name='org.tukaani.xz.common' version='1.8.0'/>
        <provided namespace='java.package' name='org.tukaani.xz.delta' version='1.8.0'/>
        <provided namespace='java.package' name='org.tukaani.xz.index' version='1.8.0'/>
        <provided namespace='java.package' name='org.tukaani.xz.lz' version='1.8.0'/>
        <provided namespace='java.package' name='org.tukaani.xz.lzma' version='1.8.0'/>
        <provided namespace='java.package' name='org.tukaani.xz.rangecoder' version='1.8.0'/>
        <provided namespace='java.package' name='org.tukaani.xz.simple' version='1.8.0'/>
        <provided namespace='osgi.identity' name='org.tukaani.xz' version='1.8.0.v20180207-1613'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='java.package' name='org.tukaani.xz' range='[1.8.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.tukaani.xz.check' range='[1.8.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.tukaani.xz.common' range='[1.8.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.tukaani.xz.delta' range='[1.8.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.tukaani.xz.index' range='[1.8.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.tukaani.xz.lz' range='[1.8.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.tukaani.xz.lzma' range='[1.8.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.tukaani.xz.rangecoder' range='[1.8.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.tukaani.xz.simple' range='[1.8.0,2.0.0)' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.tukaani.xz
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.tukaani.xz' version='1.8.0.v20180207-1613'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.tukaani.xz&#xA;Bundle-Version: 1.8.0.v20180207-1613
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.org.eclipse.update.feature.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </requires>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            uninstallFeature(feature:${artifact},featureId:default,featureVersion:default)
          </instruction>
          <instruction key='install'>
            installFeature(feature:${artifact},featureId:default,featureVersion:default)
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.osgi.bundle.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='0.0.0' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='0.0.0' multiple='true' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:4);
          </instruction>
          <instruction key='unconfigure'>

          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.source.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='source' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='source' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            removeSourceBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            addSourceBundle(bundle:${artifact})
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.sonatype.p2.runtime.config.win32.win32.x86_64' version='1.0.0' singleton='false'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.sonatype.p2.runtime.config.win32.win32.x86_64' version='1.0.0'/>
        <provided namespace='toolingorg.sonatype.p2.runtime' name='org.sonatype.p2.runtime.config' version='1.0.0'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='configure'>
            setProgramProperty(propName:eclipse.product,propValue:org.eclipse.equinox.p2.director.product);setProgramProperty(propName:eclipse.application,propValue:org.eclipse.equinox.p2.director);
          </instruction>
          <instruction key='unconfigure'>
            setProgramProperty(propName:eclipse.product,propValue:);setProgramProperty(propName:eclipse.application,propValue:);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.sonatype.p2.runtime.configuration' version='1.0.0'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.sonatype.p2.runtime.configuration' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.core.net' range='[1.0.0,1.0.0]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.registry' range='[1.0.0,1.0.0]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.apache.felix.scr' range='[1.0.0,1.0.0]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.common' range='[1.0.0,1.0.0]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.sonatype.p2.runtime.config.win32.win32.x86_64' range='[1.0.0,1.0.0]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.simpleconfigurator' range='[1.0.0,1.0.0]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.preferences' range='[1.0.0,1.0.0]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='toolingwin32.win32.x86_64org.apache.felix.scr' version='1.0.0' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.apache.felix.scr' range='2.1.16.v20200110-1820'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.apache.felix.scr' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolingwin32.win32.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.apache.felix.scr' range='2.1.16.v20200110-1820'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingwin32.win32.x86_64org.eclipse.core.net' version='1.0.0' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.net' range='1.3.900.v20200428-1255'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.core.net' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolingwin32.win32.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.net' range='1.3.900.v20200428-1255'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:4);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingwin32.win32.x86_64org.eclipse.equinox.common' version='1.0.0' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.12.0.v20200504-1602'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.common' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolingwin32.win32.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.12.0.v20200504-1602'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingwin32.win32.x86_64org.eclipse.equinox.preferences' version='1.0.0' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='3.8.0.v20200422-1833'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.preferences' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolingwin32.win32.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='3.8.0.v20200422-1833'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:4);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingwin32.win32.x86_64org.eclipse.equinox.registry' version='1.0.0' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='3.8.800.v20200406-0956'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.registry' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolingwin32.win32.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='3.8.800.v20200406-0956'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:3);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingwin32.win32.x86_64org.eclipse.equinox.simpleconfigurator' version='1.0.0' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator' range='1.3.500.v20200211-1505'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.simpleconfigurator' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolingwin32.win32.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator' range='1.3.500.v20200211-1505'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:1);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
  </units>
  <iusProperties size='65'>
    <iuProperties id='org.sonatype.p2.runtime' version='1.0.0'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
      </properties>
    </iuProperties>
  </iusProperties>
</profile>
