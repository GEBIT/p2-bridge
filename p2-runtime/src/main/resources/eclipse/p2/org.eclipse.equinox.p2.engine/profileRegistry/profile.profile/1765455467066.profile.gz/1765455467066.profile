<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='profile' timestamp='1765455467066'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='C:\dev\projects\TestCases\gebit-oomph-master2\git\p2-bridge\p2-runtime\src\main\resources\eclipse'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=de_DE'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='C:\dev\projects\TestCases\gebit-oomph-master2\git\p2-bridge\p2-runtime\src\main\resources\eclipse'/>
  </properties>
</profile>
